package utils;

public interface Serializer
{
	  default String serializerFormat() {
	      return "Serializer Format is...";
	  }
  void push(Object o);
  Object pop();
  void write() throws Exception;
  void read() throws Exception;
}